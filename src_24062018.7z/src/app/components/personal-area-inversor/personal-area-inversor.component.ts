import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personal-area-inversor',
  templateUrl: './personal-area-inversor.component.html',
  styleUrls: ['./personal-area-inversor.component.css']
})
export class PersonalAreaInversorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
