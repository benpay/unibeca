export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyDjVZJqfYBw8ve9sOSW_8ljFFKW_8RaDOo",
    authDomain: "unibecabd.firebaseapp.com",
    databaseURL: "https://unibecabd.firebaseio.com",
    projectId: "unibecabd",
    storageBucket: "unibecabd.appspot.com",
    messagingSenderId: "746158314564"
  }
};
