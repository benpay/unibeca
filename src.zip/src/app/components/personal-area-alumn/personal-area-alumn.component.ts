import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personal-area-alumn',
  templateUrl: './personal-area-alumn.component.html',
  styleUrls: ['./personal-area-alumn.component.css']
})
export class PersonalAreaAlumnComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
